def hello_baz():
    print("hello from baz")