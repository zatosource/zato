def hello_bar():
    print("hello from bar")